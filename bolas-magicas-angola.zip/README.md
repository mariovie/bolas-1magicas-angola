# Bolas Mágicas de Angola

Jogo de bolas coloridas para telemóvel, com visual inspirado nas cores de Angola.

## Como publicar no GitHub Pages
1. Envie todos os ficheiros desta pasta para a raiz do repositório GitHub.
2. Abra **Settings** > **Pages**.
3. Em **Build and deployment**, escolha **Deploy from a branch**.
4. Escolha a branch **main** e a pasta **/(root)**; carregue em **Save**.
5. Aguarde alguns minutos e abra o endereço publicado pelo GitHub Pages.

O jogo guarda o recorde no dispositivo e inclui um service worker para permitir jogar offline depois de abrir o site publicado pelo menos uma vez com internet.
